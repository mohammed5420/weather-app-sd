let temp , maxTemp , minTemp ,humidiy , pressure , weather ,icon;
async function weatheR () {
    try{
        const result = await fetch ('https://api.openweathermap.org/data/2.5/weather?q=Khartoum&appid=3d66b362ce9ce56db6cbe4fb4998dc54');
        const data =await result.json();
        console.log(data);

        temp = data.main.temp;
        maxTemp = data.main.temp_max;
        minTemp = data.main.temp_min;
        humidity = data.main.humidity;
        pressure = data.main.pressure;
        weather = data.weather[0].main;
        icon = data.weather[0].icon;
        winDeg = data.wind.deg;
        windSpeed = data.wind.speed;

        return [temp,maxTemp,minTemp,humidity,pressure,winDeg,windSpeed,icon];
    }
    catch (error) {
        console.log(error);
    }
}
weatheR()
    .then(data => {
        document.querySelector('.weather-status__temp').textContent = `${Math.floor(data[0] - 273.15)}`;
        document.querySelector('.tempreture__max').textContent = `max ${Math.floor(data[1] - 273.15)}`;
        document.querySelector('.tempreture__min').textContent = `min ${Math.floor(data[2] - 273.15)}`;
        document.querySelector('.gide__humidity').textContent = `humidity ${data[3]}`;
        document.querySelector('.gide__pressure').textContent = `pressure ${data[4]}`;
        document.querySelector('.wind__direction').textContent = `Direction ${data[5]}`;
        document.querySelector('.wind__speed').textContent = `Speed ${data[6]}`;
        const img= document.querySelector('img').setAttribute("src" , 'http://openweathermap.org/img/wn/'+data[7]+'.png');
    });
